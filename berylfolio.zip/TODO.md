# TODO

- [ ] **Portrait, introduction, and responsive navigation** — Build a welcoming hero section featuring Beryl’s name, her supplied personal picture, and a concise professional introduction; provide responsive navigation and layouts optimized for mobile, tablet, and desktop. The original request is: “I want to build a portfolio website with my picture. Am Beryl.”
- [ ] **About Beryl** — Include an About section for Beryl’s background, skills, and interests. Do not invent personal background or qualifications that were not provided.
- [ ] **Work showcase** — Include a portfolio section with visually clear project or work showcase cards. Do not represent invented projects as Beryl’s real work.
- [ ] **Contact and profiles** — Include contact details and links to Beryl’s relevant social or professional profiles. Do not fabricate addresses or profile URLs when none were supplied; keep missing details clearly editable or indicate where they should be added.
