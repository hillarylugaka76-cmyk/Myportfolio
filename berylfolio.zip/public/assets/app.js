(() => {
  'use strict';

  const STORAGE_KEY = 'beryl-portfolio-v1';
  const DEFAULT_PROFILE = {
    name: 'Beryl',
    about: 'I’m Beryl. This is my little corner of the internet — a place to share my ideas, my work, and the things that make me, me. I believe there’s something special in staying curious and making space for what comes next.',
    email: '',
    instagram: '',
    linkedin: '',
    projects: [
      { title: 'A new idea', description: 'A space for a story worth sharing.', url: '' },
      { title: 'A little experiment', description: 'A space to explore something different.', url: '' },
      { title: 'The next chapter', description: 'A space for what comes next.', url: '' },
    ],
  };

  const isString = (value) => typeof value === 'string';
  const trimmedString = (value) => (isString(value) ? value.trim() : '');

  function parseHttpUrl(value, allowedDomain) {
    const candidate = trimmedString(value);
    if (!candidate || !/^https?:\/\//i.test(candidate)) return '';

    try {
      const parsed = new URL(candidate);
      if (!['http:', 'https:'].includes(parsed.protocol) || !parsed.hostname || parsed.username || parsed.password) {
        return '';
      }

      if (allowedDomain) {
        const hostname = parsed.hostname.toLowerCase().replace(/\.$/, '');
        if (hostname !== allowedDomain && !hostname.endsWith(`.${allowedDomain}`)) return '';
      }
      return parsed.href;
    } catch (_error) {
      return '';
    }
  }

  function isValidEmail(value) {
    const candidate = trimmedString(value);
    if (!candidate || /\s/.test(candidate)) return false;
    const at = candidate.lastIndexOf('@');
    if (at <= 0 || at === candidate.length - 1) return false;
    const domain = candidate.slice(at + 1);
    return domain.includes('.') && !domain.startsWith('.') && !domain.endsWith('.') && !domain.includes('..');
  }

  function normalizeProfile(value) {
    const input = value && typeof value === 'object' ? value : {};
    const profile = {
      name: trimmedString(input.name) || DEFAULT_PROFILE.name,
      about: isString(input.about) ? input.about : DEFAULT_PROFILE.about,
      email: isValidEmail(input.email) ? trimmedString(input.email) : '',
      instagram: parseHttpUrl(input.instagram, 'instagram.com'),
      linkedin: parseHttpUrl(input.linkedin, 'linkedin.com'),
      projects: [],
    };

    DEFAULT_PROFILE.projects.forEach((defaults, index) => {
      const project = Array.isArray(input.projects) && input.projects[index] && typeof input.projects[index] === 'object'
        ? input.projects[index]
        : {};
      profile.projects.push({
        title: trimmedString(project.title) || defaults.title,
        description: trimmedString(project.description) || defaults.description,
        url: parseHttpUrl(project.url),
      });
    });
    return profile;
  }

  function readSavedProfile() {
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY);
      if (!saved) return normalizeProfile(DEFAULT_PROFILE);
      return normalizeProfile(JSON.parse(saved));
    } catch (_error) {
      return normalizeProfile(DEFAULT_PROFILE);
    }
  }

  function saveProfile(profile) {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
      return true;
    } catch (_error) {
      return false;
    }
  }

  function clearSavedProfile() {
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch (_error) {
      // Storage can be disabled by browser settings; the in-page reset still works.
    }
  }

  function makeElement(tagName, className, text) {
    const node = document.createElement(tagName);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function setText(selector, value) {
    document.querySelectorAll(selector).forEach((node) => {
      node.textContent = value;
    });
  }

  function createCloseButton(dialog, label) {
    const closeButton = makeElement('button', 'dialog-close', 'Close');
    closeButton.type = 'button';
    closeButton.setAttribute('aria-label', label);
    closeButton.addEventListener('click', () => {
      if (dialog.open) dialog.close();
    });
    return closeButton;
  }

  function addBackdropClose(dialog) {
    dialog.addEventListener('click', (event) => {
      if (event.target === dialog && dialog.open) dialog.close();
    });
  }

  function showDialog(dialog) {
    if (dialog.open) return;
    if (typeof dialog.showModal === 'function') {
      dialog.showModal();
    } else {
      // Keep the content usable in older implementations without dialog.showModal().
      dialog.setAttribute('open', '');
    }
  }

  function init() {
    let profile = readSavedProfile();

    function renderContactLinks() {
      const container = document.getElementById('contact-links');
      if (!container) return;

      const links = [];
      if (profile.email) links.push({ label: profile.email, href: `mailto:${profile.email}` });
      if (profile.instagram) links.push({ label: 'Instagram', href: profile.instagram, external: true });
      if (profile.linkedin) links.push({ label: 'LinkedIn', href: profile.linkedin, external: true });

      if (links.length === 0) {
        container.textContent = 'Contact details coming soon.';
        return;
      }

      container.replaceChildren();
      links.forEach((item, index) => {
        if (index > 0) {
          const separator = makeElement('span', '', ' · ');
          separator.setAttribute('aria-hidden', 'true');
          container.append(separator);
        }
        const anchor = makeElement('a', '', item.label);
        anchor.href = item.href;
        if (item.external) {
          anchor.target = '_blank';
          anchor.rel = 'noopener noreferrer';
        }
        container.append(anchor);
      });
    }

    function renderProjects() {
      profile.projects.forEach((project, index) => {
        const card = document.getElementById(`project-card-${index}`);
        if (!card) return;
        const title = card.querySelector('.project-title');
        const summary = card.querySelector('.project-summary');
        const status = card.querySelector('.project-status');
        if (title) title.textContent = project.title;
        if (summary) summary.textContent = project.description;
        if (status) status.textContent = 'PROJECT SPACE';
      });
    }

    function renderProfile() {
      setText('[data-owner-name]', profile.name);
      const aboutCopy = document.getElementById('about-copy');
      if (aboutCopy) aboutCopy.textContent = profile.about;
      renderContactLinks();
      renderProjects();
      document.title = `${profile.name} | Portfolio`;
    }

    function createProjectDialog() {
      const dialog = makeElement('dialog', 'site-dialog project-dialog');
      dialog.id = 'project-dialog';
      const inner = makeElement('div', 'dialog-inner');
      const topline = makeElement('div', 'dialog-topline');
      topline.append(makeElement('p', 'dialog-kicker', 'PROJECT DETAILS'));
      topline.append(createCloseButton(dialog, 'Close project details'));
      const title = makeElement('h2', 'project-dialog-title');
      title.id = 'project-dialog-title';
      const description = makeElement('p', 'dialog-intro');
      const note = makeElement('p', 'project-dialog-note');
      const action = makeElement('a', 'button button-primary', 'View project');
      action.target = '_blank';
      action.rel = 'noopener noreferrer';
      inner.append(topline, title, description, note, action);
      dialog.append(inner);
      dialog.setAttribute('aria-labelledby', title.id);
      addBackdropClose(dialog);
      document.body.append(dialog);
      return { dialog, title, description, note, action };
    }

    let projectDialogParts = null;
    function openProjectDialog(index) {
      if (!Number.isInteger(index) || index < 0 || index >= profile.projects.length) return;
      if (!projectDialogParts) projectDialogParts = createProjectDialog();
      const { dialog, title, description, note, action } = projectDialogParts;
      const project = profile.projects[index];
      title.textContent = project.title;
      description.textContent = project.description;
      if (project.url) {
        note.hidden = true;
        note.textContent = '';
        action.href = project.url;
        action.hidden = false;
      } else {
        action.removeAttribute('href');
        action.hidden = true;
        note.textContent = 'This project space is ready for Beryl’s work. Details will be added here.';
        note.hidden = false;
      }
      showDialog(dialog);
    }

    document.querySelectorAll('.project-open').forEach((button) => {
      button.addEventListener('click', () => {
        const index = Number(button.dataset.project);
        openProjectDialog(index);
      });
    });

    const menuToggle = document.getElementById('menu-toggle');
    const mainNav = document.getElementById('main-nav');
    function setNavOpen(open) {
      if (!menuToggle || !mainNav) return;
      mainNav.classList.toggle('is-open', open);
      menuToggle.setAttribute('aria-expanded', String(open));
    }

    if (menuToggle && mainNav) {
      menuToggle.setAttribute('aria-controls', mainNav.id || 'main-nav');
      setNavOpen(mainNav.classList.contains('is-open'));
      menuToggle.addEventListener('click', () => {
        setNavOpen(!mainNav.classList.contains('is-open'));
      });
      mainNav.querySelectorAll('a').forEach((anchor) => {
        anchor.addEventListener('click', () => setNavOpen(false));
      });
      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && mainNav.classList.contains('is-open')) {
          setNavOpen(false);
        }
      });
    }

    function makeField({ id, label, type = 'text', value = '', multiline = false, required = false, autocomplete = '' }) {
      const wrapper = makeElement('div', 'form-field');
      const labelNode = makeElement('label', '', label);
      labelNode.htmlFor = id;
      const control = makeElement(multiline ? 'textarea' : 'input');
      control.id = id;
      control.name = id;
      if (!multiline) control.type = type;
      if (autocomplete) control.autocomplete = autocomplete;
      if (required) control.required = true;
      control.value = value;
      if (id === 'editor-name') control.autofocus = true;
      const error = makeElement('p', 'field-error');
      error.id = `${id}-error`;
      error.hidden = true;
      error.setAttribute('aria-live', 'polite');
      control.setAttribute('aria-describedby', error.id);
      wrapper.append(labelNode, control, error);
      return { wrapper, control, error };
    }

    function createEditorDialog() {
      const dialog = makeElement('dialog', 'site-dialog editor-dialog');
      dialog.id = 'editor-dialog';
      dialog.setAttribute('aria-labelledby', 'editor-dialog-title');
      const inner = makeElement('div', 'dialog-inner');
      const topline = makeElement('div', 'dialog-topline');
      topline.append(makeElement('p', 'dialog-kicker', 'YOUR PAGE'));
      topline.append(createCloseButton(dialog, 'Close personalization editor'));
      const heading = makeElement('h2', 'dialog-title', 'Make this page yours');
      heading.id = 'editor-dialog-title';
      const intro = makeElement('p', 'dialog-intro', 'Add the details you’d like visitors to see. You can change or remove them at any time.');
      const form = makeElement('form', 'editor-form');
      form.noValidate = true;

      const fields = {};
      const nameField = makeField({ id: 'editor-name', label: 'Name', value: profile.name, required: true, autocomplete: 'name' });
      fields.name = nameField;
      const aboutField = makeField({ id: 'editor-about', label: 'About', multiline: true, value: profile.about });
      fields.about = aboutField;
      form.append(nameField.wrapper, aboutField.wrapper);

      const emailField = makeField({ id: 'editor-email', label: 'Email', type: 'email', value: profile.email, autocomplete: 'email' });
      fields.email = emailField;
      const socialRow = makeElement('div', 'form-row');
      const instagramField = makeField({ id: 'editor-instagram', label: 'Instagram URL', type: 'url', value: profile.instagram });
      const linkedinField = makeField({ id: 'editor-linkedin', label: 'LinkedIn URL', type: 'url', value: profile.linkedin });
      fields.instagram = instagramField;
      fields.linkedin = linkedinField;
      socialRow.append(instagramField.wrapper, linkedinField.wrapper);
      form.append(emailField.wrapper, socialRow);

      const projectDetails = makeElement('details', 'project-editor-details');
      const projectSummary = makeElement('summary', '', 'Optional project details');
      projectDetails.append(projectSummary);
      const projectFields = [];
      profile.projects.forEach((project, index) => {
        const group = makeElement('div', 'project-editor-fields');
        const groupTitle = makeElement('h3', '', `Project ${index + 1}`);
        const titleField = makeField({ id: `editor-project-${index}-title`, label: 'Title', value: project.title });
        const descriptionField = makeField({ id: `editor-project-${index}-description`, label: 'Description', multiline: true, value: project.description });
        const urlField = makeField({ id: `editor-project-${index}-url`, label: 'Project URL (optional)', type: 'url', value: project.url });
        projectFields.push({ title: titleField, description: descriptionField, url: urlField });
        group.append(groupTitle, titleField.wrapper, descriptionField.wrapper, urlField.wrapper);
        projectDetails.append(group);
      });
      form.append(projectDetails);

      const privacyHint = makeElement('p', 'form-hint', 'Changes are saved in this browser only. They don’t update the published website.');
      const actions = makeElement('div', 'editor-actions');
      const resetButton = makeElement('button', 'button button-secondary', 'Reset to defaults');
      resetButton.type = 'button';
      const cancelButton = makeElement('button', 'button button-secondary', 'Cancel');
      cancelButton.type = 'button';
      cancelButton.addEventListener('click', () => {
        if (dialog.open) dialog.close();
      });
      const saveButton = makeElement('button', 'button button-primary', 'Save changes');
      saveButton.type = 'submit';
      actions.append(resetButton, cancelButton, saveButton);
      form.append(privacyHint, actions);
      inner.append(topline, heading, intro, form);
      dialog.append(inner);
      addBackdropClose(dialog);

      function clearErrors() {
        Object.values(fields).forEach((field) => clearFieldError(field));
        projectFields.forEach((project) => Object.values(project).forEach((field) => clearFieldError(field)));
      }

      function populateEditor() {
        fields.name.control.value = profile.name;
        fields.about.control.value = profile.about;
        fields.email.control.value = profile.email;
        fields.instagram.control.value = profile.instagram;
        fields.linkedin.control.value = profile.linkedin;
        profile.projects.forEach((project, index) => {
          projectFields[index].title.control.value = project.title;
          projectFields[index].description.control.value = project.description;
          projectFields[index].url.control.value = project.url;
        });
        clearErrors();
      }

      function collectAndValidate() {
        clearErrors();
        const errors = [];
        const name = fields.name.control.value.trim();
        if (!name) errors.push([fields.name, 'Please enter a name.']);

        const emailValue = fields.email.control.value.trim();
        if (emailValue && (!isValidEmail(emailValue) || !fields.email.control.validity.valid)) {
          errors.push([fields.email, 'Enter a valid email address.']);
        }
        const instagramValue = fields.instagram.control.value.trim();
        if (instagramValue && !parseHttpUrl(instagramValue, 'instagram.com')) {
          errors.push([fields.instagram, 'Enter an http:// or https:// URL on instagram.com.']);
        }
        const linkedinValue = fields.linkedin.control.value.trim();
        if (linkedinValue && !parseHttpUrl(linkedinValue, 'linkedin.com')) {
          errors.push([fields.linkedin, 'Enter an http:// or https:// URL on linkedin.com.']);
        }

        const projects = [];
        projectFields.forEach((projectFieldsForOne, index) => {
          const title = projectFieldsForOne.title.control.value.trim();
          const description = projectFieldsForOne.description.control.value.trim();
          const rawUrl = projectFieldsForOne.url.control.value.trim();
          const url = rawUrl ? parseHttpUrl(rawUrl) : '';
          if (rawUrl && !url) {
            errors.push([projectFieldsForOne.url, 'Enter a complete http:// or https:// URL.']);
          }
          const defaults = DEFAULT_PROFILE.projects[index];
          projects.push({
            title: title || defaults.title,
            description: description || defaults.description,
            url,
          });
        });

        errors.forEach(([field, message]) => setFieldError(field, message));
        if (errors.length) {
          errors[0][0].control.focus();
          return null;
        }

        return normalizeProfile({
          name,
          about: fields.about.control.value,
          email: emailValue,
          instagram: instagramValue,
          linkedin: linkedinValue,
          projects,
        });
      }

      form.addEventListener('submit', (event) => {
        event.preventDefault();
        const nextProfile = collectAndValidate();
        if (!nextProfile) return;
        profile = nextProfile;
        saveProfile(profile);
        renderProfile();
        dialog.close();
      });

      resetButton.addEventListener('click', () => {
        profile = normalizeProfile(DEFAULT_PROFILE);
        clearSavedProfile();
        renderProfile();
        dialog.close();
      });

      document.body.append(dialog);
      return { dialog, populate: populateEditor };
    }

    function clearFieldError(field) {
      field.error.textContent = '';
      field.error.hidden = true;
      field.control.removeAttribute('aria-invalid');
    }

    function setFieldError(field, message) {
      field.error.textContent = message;
      field.error.hidden = false;
      field.control.setAttribute('aria-invalid', 'true');
    }

    let editorDialog = null;
    const customizeButton = document.getElementById('customize-button');
    if (customizeButton) {
      customizeButton.addEventListener('click', () => {
        if (!editorDialog) editorDialog = createEditorDialog();
        editorDialog.populate();
        showDialog(editorDialog.dialog);
      });
    }

    const year = document.getElementById('year');
    if (year) year.textContent = String(new Date().getFullYear());

    const revealElements = document.querySelectorAll('.reveal');
    const reducedMotion = typeof window.matchMedia === 'function'
      && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (revealElements.length) {
      if (reducedMotion || !('IntersectionObserver' in window)) {
        revealElements.forEach((element) => element.classList.add('is-visible'));
      } else {
        const observer = new IntersectionObserver((entries, currentObserver) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add('is-visible');
              currentObserver.unobserve(entry.target);
            }
          });
        }, { threshold: 0.12 });
        revealElements.forEach((element) => observer.observe(element));
      }
    }

    renderProfile();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
